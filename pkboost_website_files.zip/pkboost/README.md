# PkBoost — Creator Toolkit Demo

A mobile-friendly, original dark-theme interface inspired by the general idea of a social creator toolkit. It is not a copy of Zefoy and is not affiliated with TikTok.

## Run locally
Open `index.html` in any modern browser.

## Free hosting (GitHub Pages)
1. Sign in to GitHub and create a new public repository, e.g. `pkboost`.
2. Upload `index.html` and this `README.md`.
3. In repository **Settings → Pages**, select **Deploy from a branch**.
4. Choose the `main` branch and `/ (root)`, then save.
5. Wait for the published URL shown in Pages settings.

Alternative: upload the files to a static hosting service that supports free HTML hosting.

## Included tools
- Engagement planning helper
- Local post scheduler (does not publish)
- Caption draft generator
- Engagement rate estimate calculator
- Hashtag idea generator
- Creator publishing checklist

## Important
This is a front-end demo. It does not connect to TikTok, log in to accounts, or generate fake likes, views, or followers. No server or API keys are required.
